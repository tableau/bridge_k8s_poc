This is an initial empty repository. You should copy the source code of the appropiate service.

For example, the source code of tableau_bridge contains these files:
* /build.sh
* /buildspec.yaml

When you copy to this repository, the files should be in the root directory. It is an error to copy the files to a subdirectory (e.g. /tableau_bridge/buildspec.yaml)

